# webscrapping_UIS
This is a webscrapping project focused on getting information from searchers located on UIS main page. 
